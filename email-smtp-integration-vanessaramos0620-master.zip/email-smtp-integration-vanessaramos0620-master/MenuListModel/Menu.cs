﻿namespace MenuListModel
{
    public class Menu
    {
        public int Id { get; set; } 
        public string Category { get; set; }
        public string Item { get; set; }
        public decimal Price { get; set; }
    }
}
 